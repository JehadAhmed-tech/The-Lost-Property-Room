# Lost & Found Backend

Backend for the Lost & Found Management System.

## Stack
- Python 3
- Flask
- Flask-SQLAlchemy
- Flask-CORS
- PyMySQL
- python-dotenv
- Werkzeug password hashing

## Database
MySQL database name:
`lost_and_found_db`

The default local configuration assumes:
- host: localhost
- port: 3306
- user: root
- password: empty

If your MySQL password is different, edit `.env`.

## Run

### Windows
1. Install Python 3.
2. Open Command Prompt/PowerShell in this folder.
3. Create a virtual environment:
   `python -m venv venv`
4. Activate:
   `venv\Scripts\activate`
5. Install:
   `pip install -r requirements.txt`
6. Copy `.env.example` to `.env` if `.env` does not already exist.
7. Run:
   `python app.py`

Server:
`http://127.0.0.1:5000`

The application automatically creates the required tables on first startup.

## API overview

Auth:
- POST `/api/auth/register`
- POST `/api/auth/login`

Lost:
- POST `/api/lost-items`
- GET `/api/lost-items`
- GET `/api/lost-items/<id>`
- PUT `/api/lost-items/<id>`
- DELETE `/api/lost-items/<id>`

Found:
- POST `/api/found-items`
- GET `/api/found-items`
- GET `/api/found-items/<id>`
- PUT `/api/found-items/<id>`
- DELETE `/api/found-items/<id>`
- PATCH `/api/found-items/<id>/return`

Matches:
- GET `/api/matches`
- GET `/api/matches/<id>`
- PATCH `/api/matches/<id>/confirm`
- PATCH `/api/matches/<id>/reject`

Dashboard:
- GET `/api/dashboard`

## Notes
This is a REST API. Your friend's frontend can call these endpoints using fetch/Axios.

For development, CORS is enabled.
